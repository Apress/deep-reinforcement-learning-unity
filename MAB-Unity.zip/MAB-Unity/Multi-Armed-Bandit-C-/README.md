# Multi-Armed-Bandit-C#
Contains C# implementation of the Multi-Armed-Bandit algorithm for RL .This uses standard UCB and epsilon greedy algorithm as a hybrid measure to trade between exploration and exploitation
